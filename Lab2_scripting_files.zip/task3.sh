if [ $# -eq 0 ]
then
echo "no arguments enter!"
elif [ $# -gt 1 ]
then
echo "arguments enter are greater than 1"
fi

for i in `ls`
do

n=(`ls -o $i`)
if [ ${n[2]} = $1 ]
then 
echo ${n[2]} $i
fi
done

