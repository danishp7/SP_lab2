#!/bin/bash

rule1()
{
	echo "no arguments enter!"
	exit 0
	
}
rule2()
{
	echo "arguments enter are greater than 6!"
	exit 0	
}
rule3()
{
	declare -i num
	declare -i var
	var=$1
	for i in `seq 1 10`
	do
	num=$var\*$i
	echo $num
	done	
}
rule4()
{
	declare -i num
	declare -i var
	var=$1
	var2=$3
	if [ $2 = "-s" ]
	then 
	for i in `seq $var2 10`
	do
	num=$var\*$i
	echo $num
	done
	fi
}
rule6()
{
	declare -i num
	declare -i var
	var=$1
	var2=$3
	v=$5 
	for i in `seq $var2 $v`
	do
	num=$var\*$i
	echo $num
	done
}
rule7()
{
	declare -i s
	declare -i start
	declare -i e
	declare -i var
	var=$1
	e=$5
	start=$3
	while [ $e -ge $start ]
	do
	s=$var\*$e
	e=`expr e-1`
	echo $s
	done
}
if [ $# -eq 0 ]
then
rule1
elif [ $# -gt 6 ]
then
rule2
elif [ $# -eq 1 ]
then
rule3 $1
elif [ $# -eq 3 ]
then
rule4 $1 $2 $3
elif [ $# -eq 5 ]
then
rule6 $1 $2 $3 $4 $5
elif [ $# -eq 6 ]
then
rule7 $1 $2 $3 $4 $5 $6
fi 
