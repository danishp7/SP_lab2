d=`pidof $1`
cd /proc/$d
cat status | grep "Pid"
cat status | grep "State"
cat status | grep "Name"
